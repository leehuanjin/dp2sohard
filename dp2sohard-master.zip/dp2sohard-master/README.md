# dp2sohard
Deallo Craft dp2sohard

This repository is for DP2 of Team dp2sohard. This team is to develop an online web page for Deallo craft's E-commerce.

Team members:
Lee Huan Jin
Hwang Chae Hyun
Samuel Tiong
